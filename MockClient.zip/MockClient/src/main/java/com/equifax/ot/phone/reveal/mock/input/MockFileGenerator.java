package com.equifax.ot.phone.reveal.mock.input;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;

public class MockFileGenerator {

	private Properties prop;

	private int totalDuplicateCount = 0;
	private int totalNonUsCount = 0;

	private Long uid = 0L;
	private Long mdn = 0L;

	public void doService(String propertyFilesPath) {
		// Load properties
		List<File> propertyFiles = (List<File>) FileUtils.listFiles(new File(propertyFilesPath),
				new String[] { "properties" }, false);

		// FileUtils.listFiles(new File(propertyFilesPath), new String {"properties"} ,
		// false);
		// Get all clients for which files should be generated from property file.
		List<String> clients = new LinkedList<String>();
		
		

		for (File fileName : propertyFiles) {
			String client = fileName.getName().split("_")[0];
			clients.add(client);
		}

		for (String client : clients) {
			// Load respective file.

			try {
				setProp(loadProperties(client, propertyFiles));
			} catch (IOException e) {
				e.printStackTrace();
				continue;
			}
			// Generate list of UID, MDN,
			File fileToWriteAddRecords = null;
			File fileToWriteDeleteRecords = null;
			String operations[] = prop.getProperty("operation.type").split(",");
			try {
				for(String s : operations) {
					if(s.equalsIgnoreCase("add")) {
						fileToWriteAddRecords = createInputFile(client, "add");
					}
					
					if (s.equalsIgnoreCase("delete")) {
						fileToWriteDeleteRecords = createInputFile(client, "delete");
					}
				}
				
				
			} catch (IOException e) {
				e.printStackTrace();
			}

			long counter = 0L;
			List<String> addFileContents = null;
			List<String> deleteFileContents = null;
			long maxRecords = Long.parseLong(prop.getProperty("max.records.create"));

			uid = Long.parseLong(prop.getProperty("uid.start"));
			mdn = Long.parseLong(prop.getProperty("mdn.start"));
			totalNonUsCount = 0;
			totalDuplicateCount = 0;

			if(fileToWriteAddRecords != null) {
				while (counter < maxRecords) {
					addFileContents = createRecordsToWriteInFile(maxRecords);
					try {
						if ((counter + addFileContents.size()) > maxRecords) {
							System.out.println("Removing exceeding records. ");
							int i = (int) ((counter + addFileContents.size()) - maxRecords);
							FileUtils.writeLines(fileToWriteAddRecords, addFileContents.subList(0, (addFileContents.size() - i)), true);
							counter = counter + addFileContents.size();
						} else {
							FileUtils.writeLines(fileToWriteAddRecords, addFileContents, true);
							counter = counter + addFileContents.size();
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				addFileContents.clear();
				counter = 0L;
			}
			
			if(fileToWriteDeleteRecords != null) {
				while (counter < maxRecords) {
					deleteFileContents = createRecordsToWriteInFile(maxRecords);
					try {
	
						if ((counter + deleteFileContents.size()) > maxRecords) {
							System.out.println("Removing exceeding records. ");
							int i = (int) ((counter + deleteFileContents.size()) - maxRecords);
							FileUtils.writeLines(fileToWriteDeleteRecords, deleteFileContents.subList(0, (deleteFileContents.size() - i)), true);
							counter = counter + deleteFileContents.size();
						} else {
							FileUtils.writeLines(fileToWriteDeleteRecords, deleteFileContents, true);
							counter = counter + deleteFileContents.size();
							//deleteFileContents.clear();
							//counter++;
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				deleteFileContents.clear();
				counter = 0L;
			}

		}

	}

	public List<String> createRecordsToWriteInFile(long maxSize) {

		List<String> list = new LinkedList<String>();

		String[] phoneTypes = prop.getProperty("customer.phone.types").split(",");
		Random r = new Random();
		String delimiter = prop.getProperty("record.field.delimiter");
		int listSize = Integer.parseInt(prop.getProperty("batch.creation.size"));
		int duplicateLimit = Integer.parseInt(prop.getProperty("max.duplicate"));
		int nonUsLimit = Integer.parseInt(prop.getProperty("max.non.us"));
		int counter = 0;
		
		if(listSize > maxSize)
			listSize = (int) maxSize;
		
		do {
			
			String toWrite = uid++ + delimiter + "1" + mdn++ + delimiter + phoneTypes[r.nextInt(2)];
			list.add(toWrite);
			counter++;
			if (isEven(r.nextInt(10)) == 1) {

				if (totalDuplicateCount < duplicateLimit && (counter < listSize)) {
					list.add(toWrite);
					totalDuplicateCount++;
					counter++;
				}

				if (totalNonUsCount < nonUsLimit && (counter < listSize)) {
					String m = "1" + (mdn++).toString();
					Integer i = r.nextInt(8);
					while (i == 1) {
						i = r.nextInt(8);
					}
					list.add(uid++ + delimiter + m.replaceFirst("1", i.toString()) + delimiter
							+ phoneTypes[r.nextInt(2)]);
					counter++;
				}
			}
			

		} while (counter < listSize);
		System.out.println("Size of the list created : " + list.size());
		return list;
	}

	private int isEven(int n) {

		// n&1 is 1, then
		// odd, else even
		return (n & 1);
	}

	public Properties loadProperties(String client, List<File> files) throws FileNotFoundException, IOException {

		File toLoad = files.stream().filter(x -> x.getName().startsWith(client)).collect(Collectors.toList()).get(0);

		Properties prop = new Properties();
		try (FileInputStream fileInputStream = new FileInputStream(toLoad)) {
			prop.load(fileInputStream);
		}
		return prop;
	}

	public File createInputFile(String client, String operation) throws IOException {

		String fileLocation = prop.getProperty("file.write.location");
		String fileNameHead = prop.getProperty("file.name.head");
		String dirDelimiter = prop.getProperty("directory.delimiter");
		String timeStamp = getTimeStamp(prop.getProperty("timestamp.format"));
		String extension = prop.getProperty("input.file.extension");
		String fileName = fileLocation + dirDelimiter + operation.toLowerCase() + dirDelimiter + fileNameHead + operation + "_" + timeStamp + extension;
		System.out.println("Creating file : " + fileName);

		File outputFile = new File(fileName);
		outputFile.createNewFile();
		return outputFile;

	}

	private String getTimeStamp(String timeStampFormat) {

		SimpleDateFormat sdf = new SimpleDateFormat(timeStampFormat);
		return sdf.format(new Date());

	}

	public Properties getProp() {
		return prop;
	}

	public void setProp(Properties prop) {
		this.prop = prop;
	}

}
