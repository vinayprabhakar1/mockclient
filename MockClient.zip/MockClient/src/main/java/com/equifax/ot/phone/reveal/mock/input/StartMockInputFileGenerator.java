package com.equifax.ot.phone.reveal.mock.input;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartMockInputFileGenerator {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub

		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		String propertyFilesPath = args[0];
		
		MockFileGenerator clientMock = (MockFileGenerator) context.getBean("inputFileGenerator");
		clientMock.doService(propertyFilesPath);
		
	}

}
