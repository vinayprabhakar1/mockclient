package com.equifax.ot.phone.reveal.mock.input;

public interface Constants {
	
	String CLIENT_NAMES = "WWN,VSTAR" ;
	
	String PROPERTY_FILE_PATH = "C:\\BuildTest\\PhoneReveal\\Zumigo\\mockclient.properties";
	
	

}
